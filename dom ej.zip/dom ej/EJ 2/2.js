function actualizarLista() {
    const items = document.querySelectorAll("#lista li");
    items.forEach(item => item.textContent = " OVIEDO ");
}