function cambiarboton() {
    var modificado = document.querySelector("h1")
    modificado.setAttribute("class","texto")
}