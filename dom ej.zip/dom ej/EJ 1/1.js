function cambiarTexto() {
    const parrafo = document.querySelector("#texto");
    parrafo.textContent = "¡YA TE VAS ?!";
}